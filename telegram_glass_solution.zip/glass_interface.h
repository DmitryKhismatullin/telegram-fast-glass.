#ifndef GLASS_INTERFACE_H
#define GLASS_INTERFACE_H

struct GlassPoint {
    float x;
    float y;
};

// Функция, которую будет вызывать iOS-приложение Telegram.
// Сам код функции будет зашит внутри скрытого бинарника.
extern "C" void processLiquidGlassMesh(
    float touchX, 
    float touchY, 
    float force, 
    float radius, 
    GlassPoint* points, 
    int count
);

#endif

